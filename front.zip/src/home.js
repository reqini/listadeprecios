import React, { useEffect, useState, useCallback } from "react";
import axios from "./utils/axios";
import {
  Container,
  TextField,
  Snackbar,
  Alert,
  Skeleton,
  Typography,
  Grid,
  InputLabel,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions
} from "@mui/material";
import Product from "./components/products";
import ShoppingCart from "./components/cart";
import Navbar from "./components/Navbar";
import ResponsiveDialog from "./components/dialog";
import logo from "./assets/logo.png";
import { useAuth } from "./AuthContext";
import ReviewSlider from "./components/ReviewSlider"; // ajustá la ruta

const Home = () => {
  const { logout } = useAuth();
  const [openThemeDialog, setOpenThemeDialog] = useState(false);

  // Nuevo estado para los colores
  const [primaryColor, setPrimaryColor] = useState(localStorage.getItem("userPrimary") || "#A47A9E");
  const [secondaryColor, setSecondaryColor] = useState(localStorage.getItem("userSecondary") || "#FBE5B2");

  // =============== NUEVO: validación de sesión ===============
  const [sessionChecked, setSessionChecked] = useState(false);
  const [sessionValid, setSessionValid] = useState(false);

  // =============== Tus estados originales ===============
  const [extras, setExtras] = useState(null);
  const [windowWidth, setWindowWidth] = useState(window.innerWidth);
  const [loading, setLoading] = useState(true);
  const [productos, setProductos] = useState([]);
  const [filtro, setFiltro] = useState("");
  const [username, setUsername] = useState("");
  const [timeOfDay, setTimeOfDay] = useState("");
  const [snackbarOpen, setSnackbarOpen] = useState(false);
  const [rango, setRango] = useState("");
  const [cart, setCart] = useState([]);
  const [openDialog, setOpenDialog] = useState(false);

  const aplicarColores = () => {
    localStorage.setItem("userPrimary", primaryColor);
    localStorage.setItem("userSecondary", secondaryColor);

    const themeMetaTag = document.querySelector('meta[name="theme-color"]');
    if (themeMetaTag) {
      themeMetaTag.setAttribute("content", primaryColor);
    }

    window.location.reload(); // recarga para aplicar todo
  };

  const onAddToCart = (product) => {
    setCart((prevCart) => [...prevCart, product]);
  };

  const clearCart = () => setCart([]);

  // Tu función original para determinar saludo según la hora
  const getTimeOfDay = useCallback(() => {
    const currentHour = new Date().getHours();
    if (currentHour >= 0 && currentHour < 5) return "¿Trabajando de madrugada? :)";
    if (currentHour < 12) return "Buen día";
    if (currentHour < 20) return "Buenas tardes";
    return "Buenas noches";
  }, []);

  // =============== NUEVO: Verificar sesión antes de todo ===============
  useEffect(() => {
    const token = localStorage.getItem("token");
    const deviceId = localStorage.getItem("deviceId");

    // Si no hay token, directo al login
    if (!token) {
      window.location.href = "/";
      return;
    }

    const validateSession = async () => {
      try {
        const { data } = await axios.post("/api/validate-session", { token, deviceId });
        if (data.valid) {
          setSessionValid(true);
        } else {
          // Sesión inválida
          localStorage.removeItem("token");
          localStorage.removeItem("activeSession");
          window.location.href = "/";
        }
      } catch (error) {
        console.error("Error al validar la sesión:", error.message);
        localStorage.removeItem("token");
        localStorage.removeItem("activeSession");
        window.location.href = "/";
      } finally {
        setSessionChecked(true);
      }
    };

    validateSession();
  }, []);

  // =============== Efecto para obtener datos de usuario, solo si la sesión es válida ===============
  useEffect(() => {
    if (!sessionValid) return;

    const fetchUserData = async () => {
      const storedUsername = localStorage.getItem("activeSession");
      if (!storedUsername) return;

      setUsername(storedUsername);

      try {
        const { data: usuarios } = await axios.get(`/api/usuarios`);
        const user = usuarios.find((u) => u.username === storedUsername);
        if (user) {
          setRango(user.rango);
        }
      } catch (error) {
        console.error("Error al obtener los datos del usuario:", error.message);
      }
    };

    fetchUserData();
    setTimeOfDay(getTimeOfDay());

    // Actualiza saludo cada hora
    const interval = setInterval(() => setTimeOfDay(getTimeOfDay()), 3600000);
    return () => clearInterval(interval);
  }, [sessionValid, getTimeOfDay]);

  // =============== Manejo de resize de ventana ===============
  useEffect(() => {
    if (!sessionValid) return;
    const handleResize = () => setWindowWidth(window.innerWidth);
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, [sessionValid]);

  // =============== Función reutilizable para fetch data ===============
  const fetchData = useCallback(async (endpoint, setState) => {
    try {
      const { data } = await axios.get(`/api/${endpoint}`);
      setState(data);
      setTimeout(() => {
        setLoading(false);
      }, 500);
    } catch (error) {
      console.error(`Error al obtener ${endpoint}:`, error);
      setLoading(false);
    }
  }, []);

  // =============== Efecto para cargar productos y extras, solo si la sesión es válida ===============
  useEffect(() => {
    if (!sessionValid) return;
    fetchData("productos", setProductos);
    fetchData("extras", setExtras);
  }, [sessionValid, fetchData]);

  // Filtra tus productos
const productosFiltrados = productos.filter(
  (producto) =>
    (producto?.descripcion || '').toLowerCase().includes(filtro.toLowerCase()) &&
    producto?.vigencia === "SI"
);


  // Cerrar snackbar
  const handleSnackbarClose = (event, reason) => {
    if (reason === "clickaway") return;
    setSnackbarOpen(false);
  };

  // Cerrar modal
  const handleCloseDialog = () => {
    setOpenDialog(false);
  };

  // Renderizar banner según rango
  const getBannerForRango = () => {
    const rangosGrupo1 = [
      "Demostrador/a",
      "Demostrador/a plata",
      "Demostrador/a oro",
      "Coordinador/a",
      "Coordinador/a diamante",
      "Ejecutivo/a",
      "Ejecutivo/a senior",
      "Ejecutivo/a máster",
      "Ejecutivo/a premium",
      "Empresario/a",
      "Empresario/a VIP",
    ];
    /* const rangosGrupo2 = [
      "Ejecutivo/a",
      "Ejecutivo/a senior",
      "Ejecutivo/a máster",
      "Ejecutivo/a premium",
      "Empresario/a",
      "Empresario/a VIP",
    ]; */

    if (!extras || !extras[0]) {
      console.warn("Extras no disponibles o vacíos.");
      return null;
    }

    if (!rango || rango.trim() === "" || rangosGrupo1.includes(rango)) {
      return (
        <div className="banner card-product mar-b30">
          <img
            src={windowWidth <= 460 ? extras[0]?.banner_mobile : extras[0]?.banner}
            alt="Banner Grupo 1"
            style={{ width: "100%" }}
          />
        </div>
      );
    } 
    return null;
  };

  // =============== Renderizado condicional según validación de sesión ===============
  if (!sessionChecked) {
    // Esperando validación, mostramos un “cargando” (podés estilizarlo a tu gusto)
    return (
      <Container maxWidth="lg" className="conteiner-list">
        <h2>Validando sesión...</h2>
        <Skeleton sx={{ height: 50, marginTop: 2 }} animation="wave" />
        <Skeleton sx={{ height: 50, marginTop: 2 }} animation="wave" />
        <Skeleton sx={{ height: 50, marginTop: 2 }} animation="wave" />
      </Container>
    );
  }

  if (!sessionValid) {
    // Si la sesión no es válida, se habrá redirigido; retornamos null
    return null;
  }

  // Si llegamos hasta acá, la sesión es válida
  return (
    <>
      <Navbar
        title={
          <p>
            {timeOfDay} <b>{username || "Usuario"}</b>{/* , Te damos la Bienvenida */}
          </p>
        }
        user={{ username }}
        onLogout={logout}
      />
      <Container maxWidth="lg" className="conteiner-list">
        <div className="w-100 flex justify-center items-center flex-direction mar-t10">
          <Button
            variant="contained"
            color="secondary"
            size="small"
            onClick={() => setOpenThemeDialog(true)}
            sx={{ margin: 1 }}
          >
            Personalizar Colores
          </Button>
          <Typography fontSize={13} margin={'6px 0 12px 0'} style={{textAlign: 'center'}}>
            <b>Desarrollado por:</b><br></br>
            <b>
              <a href="https://www.instagram.com/cocinatyy" rel="noreferrer">@Cocinatyy </a>
            </b>
            y
            <b>
              <a href="https://www.instagram.com/lrecchini/" rel="noreferrer"> Luciano Recchini</a>
            </b>
          </Typography>
          <img src={logo} alt="logo" width="200" className="mar-t10 mar-b20" />
        </div>

        <div className="header mar-b30 flex-center pad20">
          <TextField
            style={{ maxWidth: 450 }}
            fullWidth
            className="search"
            label="Buscar Producto"
            variant="outlined"
            value={filtro}
            onChange={(e) => setFiltro(e.target.value)}
          />
        </div>
        {getBannerForRango()}
        <ReviewSlider />
        <ul className="lista-prod w-100">
          {loading ? (
            [...Array(6)].map((_, index) => (
              <Skeleton
                key={index}
                sx={{ height: 300, margin: 1 }}
                animation="wave"
                variant="rectangular"
                className="grid-item"
              />
            ))
          ) : (
            productosFiltrados.map((product) => (
              <li className="grid-item" key={product.id}>
                <Product
                  product={product}
                  cuotaType="sin_interes"
                  onAddToCart={onAddToCart}
                />
              </li>
            ))
          )}
        </ul>

        <ShoppingCart
          cart={cart}
          setCart={setCart}
          onClearCart={clearCart}
        />

        {/* Modal de promociones bancarias */}
        <ResponsiveDialog open={openDialog} onClose={handleCloseDialog} />

        <Snackbar open={snackbarOpen} autoHideDuration={3000} onClose={handleSnackbarClose}>
          <Alert onClose={handleSnackbarClose} severity="success">
            Producto agregado al carrito
          </Alert>
        </Snackbar>
        <section style={{ fontSize: '0.9rem', color: '#666', padding: '2rem 0', width: '100%' }}>
          <p>
            Catálogo Simple es una herramienta pensada para <strong>emprendedoras Essen</strong> que buscan simplificar su trabajo. Accedé gratis a la <strong>lista de precios Essen actualizada</strong>, catálogos visuales con cuotas y mucho más. 
            Ideal para quienes venden Essen en Argentina y quieren tener todo en un solo lugar.
          </p>
        </section>
        <Dialog
          open={openThemeDialog}
          onClose={() => setOpenThemeDialog(false)}
          fullWidth
          maxWidth="sm"
          sx={{
            '& .MuiDialog-paper': {
              margin: { xs: 1, sm: 2 },
              width: '100%',
            },
          }}
        >
          <DialogTitle sx={{ textAlign: 'center', fontWeight: 600 }}>
            Personalización de Tema
          </DialogTitle>

          <DialogContent sx={{ px: { xs: 2, sm: 4 }, pb: 2 }}>
            <Grid container spacing={2} mt={1}>
              <Grid item xs={12} sm={6}>
                <InputLabel>Color Primario</InputLabel>
                <TextField
                  type="color"
                  fullWidth
                  value={primaryColor}
                  onChange={(e) => setPrimaryColor(e.target.value)}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <InputLabel>Color Secundario</InputLabel>
                <TextField
                  type="color"
                  fullWidth
                  value={secondaryColor}
                  onChange={(e) => setSecondaryColor(e.target.value)}
                />
              </Grid>
            </Grid>
          </DialogContent>

          <DialogActions sx={{ px: 3, pb: 2 }}>
            <Grid container spacing={2}>
              <Grid item xs={12} sm={4}>
                <Button
                  variant="text"
                  color="primary"
                  fullWidth
                  onClick={() => setOpenThemeDialog(false)}
                >
                  Cancelar
                </Button>
              </Grid>
              <Grid item xs={12} sm={4}>
                <Button
                  fullWidth
                  variant="outlined"
                  onClick={() => {
                    setPrimaryColor("#A47A9E");
                    setSecondaryColor("#FBE5B2");
                  }}
                >
                  Colores originales
                </Button>
              </Grid>
              <Grid item xs={12} sm={4}>
                <Button
                  fullWidth
                  variant="contained"
                  onClick={aplicarColores}
                >
                  Aplicar
                </Button>
              </Grid>
            </Grid>
          </DialogActions>
        </Dialog>


      </Container>
    </>
  );
};

export default Home;