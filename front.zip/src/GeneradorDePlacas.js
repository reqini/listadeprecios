import React, { useState, useEffect } from "react";
import axios from "./utils/axios";
import { Autocomplete, TextField, Button } from "@mui/material";
import CardGenerator from "./components/CardGenerator";

const GeneradorDePlacas = () => {
  const [products, setProducts] = useState([]);
  const [banks, setBanks] = useState([]);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [selectedQuota, setSelectedQuota] = useState(null);
  const [selectedBank, setSelectedBank] = useState(null);
  const [isQuotaDisabled, setIsQuotaDisabled] = useState(true);
  const [isBankDisabled, setIsBankDisabled] = useState(true);
  const [showCard, setShowCard] = useState(false);

  const cuotasMap = {
    "3 cuotas": "tres_sin_interes",
    "6 cuotas": "seis_sin_interes",
    "9 cuotas": "nueve_sin_interes",
    "10 cuotas": "diez_sin_interes",
    "12 cuotas": "doce_sin_interes",
    "18 cuotas": "dieciocho_sin_interes",
    "20 cuotas": "veinte_sin_interes",
    "24 cuotas": "veinticuatro_sin_interes"
  };
  const quotas = Object.keys(cuotasMap);

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await axios.get("/api/productos");
        const productosFiltrados = response.data?.filter(
          (producto) =>
            producto?.linea?.toLowerCase() !== "repuestos" &&
            producto?.imagen && producto?.imagen.startsWith("http")
        ) || [];
        setProducts(productosFiltrados);
      } catch (error) {
        console.error("Error al obtener productos:", error);
        setProducts([]);
      }
    };

    const fetchBanks = async () => {
      try {
        const response = await axios.get("/api/bancos");
        setBanks(response.data || []);
      } catch (error) {
        console.error("Error al obtener bancos:", error);
        setBanks([]);
      }
    };

    fetchProducts();
    fetchBanks();
  }, []);

  const handleSelectProduct = (event, newValue) => {
    if (!newValue) return;
    setSelectedProduct({
      id: newValue.id,
      descripcion: newValue.descripcion,
      imagen: newValue.imagen,
      precio: "Precio no disponible",
      cuotas: "Sin cuotas seleccionadas",
      banco: "Sin banco asignado",
      bancoImagen: "",
      ...newValue
    });
    setIsQuotaDisabled(false);
    setShowCard(false);
  };

  const handleQuotaChange = (event, newValue) => {
    if (!newValue || !selectedProduct) return;
    setSelectedQuota(newValue);
    setIsBankDisabled(false);
    setShowCard(false);

    const cuotaKey = cuotasMap[newValue];
    const precioCuota = selectedProduct[cuotaKey] && selectedProduct[cuotaKey] !== "0" 
      ? `$${selectedProduct[cuotaKey]}`
      : "No disponible";

    setSelectedProduct((prev) => ({
      ...prev,
      precio: precioCuota,
      cuotas: newValue,
    }));
  };

  const handleBankChange = (event, newValue) => {
    if (!newValue || !selectedProduct) return;
    setSelectedBank(newValue);
    setShowCard(false);

    setSelectedProduct((prev) => ({
      ...prev,
      banco: newValue.banco,
      bancoImagen: newValue.logo || "",
    }));
  };

  const handleApply = () => {
    if (selectedProduct && selectedQuota && selectedBank) {
      setShowCard(true);
    }
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", padding: "20px" }}>
      <Autocomplete
        options={banks || []}
        getOptionLabel={(option) => option?.banco || ""}
        onChange={handleBankChange}
        renderInput={(params) => <TextField {...params} label="Selecciona Banco" variant="outlined" fullWidth />}
        style={{ width: "400px", marginBottom: "20px" }}
      />
      <Autocomplete
        options={quotas || []}
        getOptionLabel={(option) => option || ""}
        onChange={handleQuotaChange}
        renderInput={(params) => <TextField {...params} label="Selecciona Cuotas" variant="outlined" fullWidth disabled={isQuotaDisabled} />}
        style={{ width: "400px", marginBottom: "20px" }}
      />
      <Autocomplete
        options={products || []}
        getOptionLabel={(option) => option?.descripcion || ""}
        onChange={handleSelectProduct}
        renderInput={(params) => <TextField {...params} label="Selecciona un Producto" variant="outlined" fullWidth disabled={isBankDisabled} />}
        style={{ width: "400px", marginBottom: "20px" }}
      />
      <Button variant="contained" color="primary" onClick={handleApply} disabled={!selectedProduct || !selectedQuota || !selectedBank}>
        Aplicar
      </Button>
      {showCard && <CardGenerator selectedProducts={[selectedProduct]} />}
    </div>
  );
};

export default GeneradorDePlacas;
