import React from "react";
import html2canvas from "html2canvas";

const CardGenerator = ({ selectedProducts = [] }) => {
  return (
    <div id="card-container" style={{
      width: "360px",
      height: "640px",
      background: "#fff",
      position: "relative",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      borderRadius: "10px",
      overflow: "hidden",
      border: "2px solid #000",
    }}>
      <div style={{
        width: "100%",
        height: "100%",
        background: "#FFFFFF",
        position: "relative",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        borderRadius: "10px",
        overflow: "hidden",
        textAlign: "center",
        padding: "10px",
      }}>
        {selectedProducts.length > 0 ? (
          selectedProducts.map((product, index) => {
            const precioFinal = product.precio && !isNaN(parseFloat(product.precio)) 
              ? `$${parseFloat(product.precio).toFixed(2)}` 
              : "No disponible";

            return (
              <div key={index} style={{
                position: "relative",
                width: "100%",
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center'
              }}>
                <h3 style={{
                  marginTop: "10px",
                  fontSize: "32px",
                  color: "blueviolet",
                  margin: 0
                }}>
                  {product.descripcion || "Sin descripción"}
                </h3>
                <img
                  src={product.imagen || "/placeholder.png"}
                  alt={product.descripcion || "Sin imagen"}
                  style={{
                    width: "125%",
                    height: "auto",
                    objectFit: "contain",
                    borderRadius: "5px",
                    background: "white",
                  }}
                />
                <h3 style={{ fontSize: "20px", color: "#333" }}>{precioFinal}</h3>
                <h2 style={{ fontSize: "22px", fontWeight: "bold", color: "#000" }}>
                  {product.cuotas || "Sin cuotas disponibles"}
                </h2>
                <h2 style={{ fontSize: "18px", fontWeight: "bold", color: "#555" }}>
                  {product.banco ? `Banco: ${product.banco}` : "Sin banco asignado"}
                </h2>
                {product.bancoImagen && (
                  <img
                    src={product.bancoImagen}
                    alt={product.banco || "Banco desconocido"}
                    style={{ width: "80px", height: "auto", marginTop: "10px" }}
                  />
                )}
              </div>
            );
          })
        ) : (
          <h3 style={{ fontSize: "20px", color: "#777" }}>Selecciona un producto</h3>
        )}
      </div>
    </div>
  );
};

export default CardGenerator;
